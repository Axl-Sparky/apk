Sparky Android project
======================
This is a minimal Android Studio project (Kotlin). It includes your uploaded image as app/src/main/res/drawable/logo.png
How to build:
1. Download and unzip this project.
2. Open Android Studio, choose "Open" and select the folder sparky_android_project.
3. Let Android Studio sync/upgrade Gradle and generate the Gradle wrapper if missing.
4. Build > Build Bundle(s) / APK(s) > Build APK(s). The debug APK will be in app/build/outputs/apk/debug/app-debug.apk
Note: If you want the app icon changed, replace mipmap/ic_launcher resources via Android Studio Image Asset tool.
